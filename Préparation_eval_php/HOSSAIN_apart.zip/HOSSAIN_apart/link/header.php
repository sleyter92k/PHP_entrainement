<!DOCTYPE html>
<?php
    $title = "PHP Practice";
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo "<title>$title</title>"; ?>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <h1>IMFO Immobilier</h1>
        <P>Agence à Louer & Vendre Maison ou Appartement</P>
    </header>
