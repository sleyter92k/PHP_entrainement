<?php
    echo "<footer class=\"sticky-bottom\"><p>Home practice for learning PHP :". $_SERVER ['PHP_SELF']. "</p></footer>";
    echo "</body></html>";
?>

    